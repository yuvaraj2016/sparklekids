<h2>Hello Admin,</h2>
You received an email from : {{ $name }}
Here are the details:
<b>Name:</b> {{ $name }}
<b>Email:</b> {{ $email }}
<b>Phone Number:</b> {{ $phone_number }}
<b>Subject:</b> {{ $subject }}
<b>Message:</b> {{ $user_message }}
Thank You
