    <!-- END nav -->
    

    <?php $__env->startSection('content'); ?>



    <section>



        <div class="heading-section ftco-animate">
            


                <h2 class="mb-4 text-center" >Photo Details</h2>

          </div>

            <!--<div class="portfolio-menu mt-2 mb-4">
               <ul>
                  <li class="btn btn-outline-dark active" data-filter="*">All</li>
                  <li class="btn btn-outline-dark" data-filter=".gts">Childran</li>
                  <li class="btn btn-outline-dark" data-filter=".lap">Course</li>
                  <li class="btn btn-outline-dark text" data-filter=".selfie">Teachers</li>
               </ul>
            </div>-->
            
             <!--  <div class="item gts col-lg-3 col-md-4 col-6 col-sm ">

               
                  <img class="img-fluid" src="images/image_6.jpg" alt="">

                  <div class="pad">Course</div>
                  </a>
               </div>
               <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
                  
                  <img class="img-fluid" src="images/image_1.jpg" alt="">
                  <div class="pad">Childran</div>
                  </a>
               </div>
               <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
                  
                  <img class="img-fluid" src="images/image_2.jpg" alt="">
                  <div class="pad">Sports</div>

                  </a>
               </div>
               <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
                  
                  <img class="img-fluid" src="images/image_3.jpg" alt="">
                  <div class="pad">Teacher</div>
                  </a>
               </div>-->
               

               <?php if(count($photodetails)==0): ?>

                <div class="row items gts justify-content-center align-items-center">
                    <div class="col-lg-12 text-center">
                        <div class="alert alert-primary">
                            <p>Sorry! There is no details for this photo.
                        </div>
                    </div>

                </div>
               <?php else: ?>
               <div class="row py-2 justify-content-center">
               

               

               <div class="item gts col-lg-6 col-md-8 col-6 col-sm text-center">

                   
                   
                   <img class="img-fluid img-responsive" src="http://restschool.hridham.com/storage/photos/<?php echo e($photodetails[0]->photo); ?>" alt="<?php echo e($photodetails[0]->photo); ?>" width="100%" height="100%">
                   

                     <p><?php echo e($photodetails[0]->photo_description); ?></p>

                </div>




                

                
            </div>
            <br/>
                <?php endif; ?>


            <div class="row justify-content-center pb-4">
                <div class="pagination">
                    <a href="<?php echo e(url()->previous()); ?>" class="album bg-primary text-white p-2">Back</a>

                    
                 </div>

            </div>

        </div>
    </div>



    </section>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sparklekids\resources\views/photodetails.blade.php ENDPATH**/ ?>