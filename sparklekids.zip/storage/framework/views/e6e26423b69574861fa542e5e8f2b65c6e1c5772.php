    <!-- END nav -->
    

    <?php $__env->startSection('content'); ?>



    <section>



        <div class="heading-section ftco-animate">
            


                <h2 class="mb-4 text-center" ><?php echo e($albumdata[0]->album_name); ?> - Photos</h2>

          </div>

            <!--<div class="portfolio-menu mt-2 mb-4">
               <ul>
                  <li class="btn btn-outline-dark active" data-filter="*">All</li>
                  <li class="btn btn-outline-dark" data-filter=".gts">Childran</li>
                  <li class="btn btn-outline-dark" data-filter=".lap">Course</li>
                  <li class="btn btn-outline-dark text" data-filter=".selfie">Teachers</li>
               </ul>
            </div>-->
            
             <!--  <div class="item gts col-lg-3 col-md-4 col-6 col-sm ">

               
                  <img class="img-fluid" src="images/image_6.jpg" alt="">

                  <div class="pad">Course</div>
                  </a>
               </div>
               <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
                  
                  <img class="img-fluid" src="images/image_1.jpg" alt="">
                  <div class="pad">Childran</div>
                  </a>
               </div>
               <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
                  
                  <img class="img-fluid" src="images/image_2.jpg" alt="">
                  <div class="pad">Sports</div>

                  </a>
               </div>
               <div class="item gts col-lg-3 col-md-4 col-6 col-sm">
                  
                  <img class="img-fluid" src="images/image_3.jpg" alt="">
                  <div class="pad">Teacher</div>
                  </a>
               </div>-->
               

               <?php if(count($photos)==0): ?>

                <div class="row items gts justify-content-center align-items-center">
                    <div class="col-lg-12 text-center">
                        <div class="alert alert-primary">
                            <p>Sorry! There is no photos in this album.
                        </div>
                    </div>

                </div>
               <?php else: ?>
               <div class="row py-2">
               <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               

               <div class="item gts col-lg-3 col-md-4 col-6 col-sm text-center pt-4">

                    <?php echo e(app()->call('App\Http\Controllers\PhotoController@imageresize',['src'=>$photo->photo])); ?>


                   <a href="http://restschool.hridham.com/storage/photos/<?php echo e($photo->photo); ?>" class="fancylight" data-fancybox-group="light">
                   <img class="img-fluid img-responsive" src="<?php echo e(url('storage/photos/'.$photo->photo)); ?>" alt="<?php echo e($photo->photo); ?>" height="100px">
                   </a>

                     <p><?php echo e($photo->photo_description); ?></p>
                     <a href="<?php echo e(url('photos/'.$photo->id)); ?>" class="album bg-primary text-white p-2">Know More</a>

                </div>




                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
            </div>
            <br/>
                <?php endif; ?>


            <div class="row justify-content-center">
                <div class="pagination">
                    <?php echo e($photos->links()); ?>

                 </div>

            </div>

        </div>
    </div>



    </section>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sparklekids\resources\views/photo.blade.php ENDPATH**/ ?>